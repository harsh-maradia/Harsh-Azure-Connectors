"""Module with constants and configurations for the BitSight integration."""
import os

API_TOKEN = os.environ.get("API_token")
AZURE_AUTHENTICATION_URL = "https://login.microsoftonline.com/{}/oauth2/token"
BASE_URL = "https://api.bitsighttech.com"
ENDPOINTS = {
    "portfolio_path": "/ratings/v2/portfolio",
    "breaches_endpoint_path": "/v1/companies/{}/providers/breaches",
    "findings_endpoint_path": "/ratings/v1/companies/{}/findings",
    "alerts_data_url": "/v2/alerts/",
}
PORTFOLIO_PAGE_SIZE = 500
FINDINGS_PAGE_SIZE = 1000
ALERTS_PAGE_SIZE = 1000
AZURE_CLIENT_ID = os.environ.get("AZURE_CLIENT_ID")
AZURE_CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET")
AZURE_TENANT_ID = os.environ.get("AZURE_TENANT_ID")
CONN_STRING = os.environ.get("AzureWebJobsStorage")
TABLE_SERVICE_URI = os.environ.get("AzureWebJobsStorage__tableServiceUri")
COMPANIES = os.environ.get("Companies")
WORKSPACE_ID = os.environ.get("WorkspaceID")
COMPANIES_TABLE_NAME = os.environ.get("Portfolio_Companies_Table_Name")
BREACHES_TABLE_NAME = os.environ.get("Breaches_Table_Name")
FINDINGS_TABLE_NAME = os.environ.get("Findings_Table_Name")
ALERTS_DATA_TYPE = "alerts_data"
ALERTS_DATA_TABLE = os.environ.get("Alerts_Table_Name")
AZURE_DATA_COLLECTION_ENDPOINT = os.environ["AZURE_DATA_COLLECTION_ENDPOINT"]
AZURE_DATA_COLLECTION_RULE_ID_COMPANY_TABLES = os.environ["AZURE_DATA_COLLECTION_RULE_ID_COMPANY_TABLES"]
AZURE_DATA_COLLECTION_RULE_ID_DATA_TABLES = os.environ["AZURE_DATA_COLLECTION_RULE_ID_DATA_TABLES"]
TABLE_NAME_RULE_ID_MAPPING = {
    COMPANIES_TABLE_NAME: AZURE_DATA_COLLECTION_RULE_ID_COMPANY_TABLES,
    BREACHES_TABLE_NAME: AZURE_DATA_COLLECTION_RULE_ID_DATA_TABLES,
    FINDINGS_TABLE_NAME: AZURE_DATA_COLLECTION_RULE_ID_DATA_TABLES,
    ALERTS_DATA_TABLE: AZURE_DATA_COLLECTION_RULE_ID_DATA_TABLES,
}
SCOPE = os.environ["SCOPE"]
LOGS_STARTS_WITH = "BitSight:"
BREACHES_FUNC_NAME = "Breaches:"
FINDINGS_FUNC_NAME = "Findings:"
ALERT_GRAPH_STATISTICS_FUNC_NAME = "Alerts-Graph-statistics Details:"
PORTFOLIO_COMPANY_QUERY = """{}_CL
    | summarize arg_max(TimeGenerated, *) by guid
    | sort by name asc
    | project name, guid""".format(
        COMPANIES_TABLE_NAME
    )
ALERTS_DATA_CHECKPOINT_TABLE = "BitSightAlertsCheckpoint"
BREACHES_CHECKPOINT_TABLE = "BitSightBreachesCheckpoint"
FINDINGS_CHECKPOINT_TABLE = "BitSightFindingsCheckpoint"
PORTFOLIO_COMPANY_CHECKPOINT_TABLE = "BitSightPortfolioCompanyCheckpoint"
COMPANY_CHECKPOINT_PARTITION_KEY = "company"
DATA_CHECKPOINT_PARTITION_KEY = "data"
COMPANY_CHECKPOINT_ROW_KEY = "company"
RETRY_COUNT = 3
RETRY_AFTER = 29
FUNCTION_APP_TIMEOUT_SECONDS = 540
